// Template main.js
// Replace this comment with your own custom code.
// This file must exist for the extension to install, even if empty.

export default {
    id: "mangaworld",
    name: "MangaWorld",
    version: 1,
    language: "en",

    // Tachimanga requires these functions to exist,
    // but they can be empty placeholders.
    async getMangaList() {
        return [];
    },

    async getMangaDetails(id) {
        return {};
    },

    async getChapters(id) {
        return [];
    },

    async getChapterPages(chapterId) {
        return [];
    }
};
